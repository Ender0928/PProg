var searchData=
[
  ['object_2ec_86',['object.c',['../object_8c.html',1,'']]],
  ['object_2eh_87',['object.h',['../object_8h.html',1,'']]],
  ['object_5fcreate_88',['object_create',['../object_8c.html#abb0cd30fca5fbddf137c6c04df66bbc7',1,'object_create(Id id):&#160;object.c'],['../object_8h.html#abb0cd30fca5fbddf137c6c04df66bbc7',1,'object_create(Id id):&#160;object.c']]],
  ['object_5fdestroy_89',['object_destroy',['../object_8c.html#a19d6d51fee809e3801893eefc789f4b4',1,'object_destroy(Object *object):&#160;object.c'],['../object_8h.html#a19d6d51fee809e3801893eefc789f4b4',1,'object_destroy(Object *object):&#160;object.c']]],
  ['object_5fget_5fdescription_90',['object_get_description',['../object_8c.html#a4b26ef1ec7057673899b58a5bf55f06a',1,'object_get_description(Object *object):&#160;object.c'],['../object_8h.html#a4b26ef1ec7057673899b58a5bf55f06a',1,'object_get_description(Object *object):&#160;object.c']]],
  ['object_5fget_5fid_91',['object_get_id',['../object_8c.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c'],['../object_8h.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c']]],
  ['object_5fget_5fname_92',['object_get_name',['../object_8c.html#a19320eebcbbd38533a18c741b804b584',1,'object_get_name(Object *object):&#160;object.c'],['../object_8h.html#a19320eebcbbd38533a18c741b804b584',1,'object_get_name(Object *object):&#160;object.c']]],
  ['object_5fprint_93',['object_print',['../object_8c.html#adebb77fb5d33fc70616ab3b2b64c27ce',1,'object_print(Object *object):&#160;object.c'],['../object_8h.html#adebb77fb5d33fc70616ab3b2b64c27ce',1,'object_print(Object *object):&#160;object.c']]],
  ['object_5fset_5fdescription_94',['object_set_description',['../object_8c.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c'],['../object_8h.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c']]],
  ['object_5fset_5fid_95',['object_set_id',['../object_8c.html#a8c03688ce63530d822523f23066960ee',1,'object_set_id(Object *object, Id id):&#160;object.c'],['../object_8h.html#a8c03688ce63530d822523f23066960ee',1,'object_set_id(Object *object, Id id):&#160;object.c']]],
  ['object_5fset_5fname_96',['object_set_name',['../object_8c.html#ac15dc062c857503ec0ca66037caffd80',1,'object_set_name(Object *object, char *name):&#160;object.c'],['../object_8h.html#ac15dc062c857503ec0ca66037caffd80',1,'object_set_name(Object *object, char *name):&#160;object.c']]],
  ['object_5ftest_2eh_97',['object_test.h',['../object__test_8h.html',1,'']]],
  ['objects_98',['objects',['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space']]],
  ['origin_99',['origin',['../struct__Link.html#af039079d7500b5ab11ae21ef672cbf5f',1,'_Link']]]
];
