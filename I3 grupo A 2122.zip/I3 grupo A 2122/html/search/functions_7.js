var searchData=
[
  ['screen_5farea_5fclear_277',['screen_area_clear',['../libscreen_8h.html#a0950dc68cba3d491b909a8abaac1c666',1,'libscreen.h']]],
  ['screen_5farea_5fdestroy_278',['screen_area_destroy',['../libscreen_8h.html#aca5123ed5a7afb75e79c0001e5d1df4f',1,'libscreen.h']]],
  ['screen_5farea_5finit_279',['screen_area_init',['../libscreen_8h.html#a194528bec3ed3b57618a8f2df9bea743',1,'libscreen.h']]],
  ['screen_5farea_5fputs_280',['screen_area_puts',['../libscreen_8h.html#a4f4cd4c7899c096d6c90cc33de9a9814',1,'libscreen.h']]],
  ['screen_5farea_5freset_5fcursor_281',['screen_area_reset_cursor',['../libscreen_8h.html#af77fa9df4f7170e1e3bf1c6209b7f0c2',1,'libscreen.h']]],
  ['screen_5fdestroy_282',['screen_destroy',['../libscreen_8h.html#a3d6d82dde2bb4f3ddc4d276dabe313ef',1,'libscreen.h']]],
  ['screen_5finit_283',['screen_init',['../libscreen_8h.html#a3c7e0099996732d34b143dde1a40f02c',1,'libscreen.h']]],
  ['screen_5fpaint_284',['screen_paint',['../libscreen_8h.html#a3eaa0547a956d39b6c55c9593524e0d1',1,'libscreen.h']]],
  ['space_5fadd_5fobject_285',['space_add_object',['../space_8c.html#a69b9e22046b7b44dc5aa2afe7cc0a1b9',1,'space_add_object(Space *space, Id id):&#160;space.c'],['../space_8h.html#a69b9e22046b7b44dc5aa2afe7cc0a1b9',1,'space_add_object(Space *space, Id id):&#160;space.c']]],
  ['space_5fcreate_286',['space_create',['../space_8c.html#a162866fcea156b800fd546d0ffd271c9',1,'space_create(Id id):&#160;space.c'],['../space_8h.html#a162866fcea156b800fd546d0ffd271c9',1,'space_create(Id id):&#160;space.c']]],
  ['space_5fdel_5fobject_287',['space_del_object',['../space_8c.html#a32c30f0aa89f3f28c06802f1c72c1fdc',1,'space_del_object(Space *space, Id id):&#160;space.c'],['../space_8h.html#a32c30f0aa89f3f28c06802f1c72c1fdc',1,'space_del_object(Space *space, Id id):&#160;space.c']]],
  ['space_5fdestroy_288',['space_destroy',['../space_8c.html#a5c70c70398923693ddbe4dfac8d72a0d',1,'space_destroy(Space *space):&#160;space.c'],['../space_8h.html#a5c70c70398923693ddbe4dfac8d72a0d',1,'space_destroy(Space *space):&#160;space.c']]],
  ['space_5fget_5fdescription_289',['space_get_description',['../space_8c.html#a51e854a2f9b35bd39e60c04ec5f03abd',1,'space_get_description(Space *space):&#160;space.c'],['../space_8h.html#a51e854a2f9b35bd39e60c04ec5f03abd',1,'space_get_description(Space *space):&#160;space.c']]],
  ['space_5fget_5fid_290',['space_get_id',['../space_8c.html#ac8ddfd0d8692fd852ee49698c446cb50',1,'space_get_id(Space *space):&#160;space.c'],['../space_8h.html#ac8ddfd0d8692fd852ee49698c446cb50',1,'space_get_id(Space *space):&#160;space.c']]],
  ['space_5fget_5fname_291',['space_get_name',['../space_8c.html#a310c540cd6e11073f7328add1f927001',1,'space_get_name(Space *space):&#160;space.c'],['../space_8h.html#a310c540cd6e11073f7328add1f927001',1,'space_get_name(Space *space):&#160;space.c']]],
  ['space_5fprint_292',['space_print',['../space_8c.html#a18eca058da6cdf20ae5eda9d122d992e',1,'space_print(Space *space):&#160;space.c'],['../space_8h.html#a18eca058da6cdf20ae5eda9d122d992e',1,'space_print(Space *space):&#160;space.c']]],
  ['space_5fset_5fdescription_293',['space_set_description',['../space_8c.html#a7aecc426029f567d452a0f916fd512d6',1,'space_set_description(Space *space, char *description):&#160;space.c'],['../space_8h.html#a7aecc426029f567d452a0f916fd512d6',1,'space_set_description(Space *space, char *description):&#160;space.c']]],
  ['space_5fset_5fname_294',['space_set_name',['../space_8c.html#aab5b468f9822ab78dbe16d1321870d93',1,'space_set_name(Space *space, char *name):&#160;space.c'],['../space_8h.html#aab5b468f9822ab78dbe16d1321870d93',1,'space_set_name(Space *space, char *name):&#160;space.c']]]
];
