var searchData=
[
  ['destination_12',['destination',['../struct__Link.html#aae5a495d4f85697715abe75da7c59cd0',1,'_Link']]],
  ['direction_13',['direction',['../struct__Link.html#a60a439916b9ae8d52e3d0c4c5e48806c',1,'_Link']]]
];
