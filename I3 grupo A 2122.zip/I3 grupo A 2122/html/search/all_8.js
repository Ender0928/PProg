var searchData=
[
  ['name_85',['name',['../struct__Link.html#a020ee863120055b29609157b9de3c84d',1,'_Link::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]]
];
